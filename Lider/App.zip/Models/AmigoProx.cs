﻿using System.Collections.Generic;

namespace PeopleProApp.Models
{
    class AmigoProx
    {
        public Amigo PontoRef { get; set; }
        public List<Amigo> lstProx { get; set; }
    }
}
